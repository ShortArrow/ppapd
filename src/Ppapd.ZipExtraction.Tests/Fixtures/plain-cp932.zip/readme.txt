This is a sample file for ppapd.
